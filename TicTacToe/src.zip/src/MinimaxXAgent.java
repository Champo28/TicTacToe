import java.util.List;
public class MinimaxXAgent {
    private static final int EASY = 1;
    private static final int MEDIUM = 3;
    private static final int HARD = 6;
    private static final int INSANE = 9;
    static int play(Ilayout board){
        int bestVal = -1000;
        int bestMove = 0;
        List<Ilayout> children = board.children();
        for(Ilayout child: children){
            int moveVal = minimax(child,0, false, Integer.MIN_VALUE, Integer.MAX_VALUE, HARD);
            if(moveVal > bestVal){
                bestVal = moveVal;
                bestMove = child.getLastMove();
            }
        }
        return bestMove;
    }

    private static int minimax(Ilayout board, int depth, boolean isMaximizingPlayer, int alpha, int beta, int maxDepth){
        if(board.isGameOver()){
            if(board.getWinner() == Ilayout.ID.X) return 10;
            if(board.getWinner() == Ilayout.ID.O) return -10;
            return 0;
        }
        if(depth == maxDepth) return 0;

        if(isMaximizingPlayer){
            int maxEval = Integer.MIN_VALUE;
            List<Ilayout> children = board.children();
            for(Ilayout child: children){
                int eval = minimax(child,depth + 1, false, alpha, beta, maxDepth);
                maxEval = Math.max(maxEval, eval);
                alpha = Math.max(alpha, maxEval);
                if(beta <= alpha) break;
            }
            return maxEval;
        }
        else{
            int minEval = Integer.MAX_VALUE;
            List<Ilayout> children = board.children();
            for(Ilayout child: children){
                int eval = minimax(child,depth + 1, true, alpha, beta, maxDepth);
                minEval = Math.min(minEval, eval);
                beta = Math.min(beta, minEval);
                if(beta <= alpha) break;
            }
            return minEval;
        }
    }
}
